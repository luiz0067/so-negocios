<?php	
	include('conecta.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title>_:: $ó Negócios ::_O maior Portal de Negócios do Paraná</title>
		<link href="css/stilo.css" rel="stylesheet" type="text/css" />
		<script src="SpryAssets/SpryMenuBar.js" type="text/javascript"></script>
		<script src="Scripts/swfobject_modified.js" type="text/javascript"></script>
		<link href="SpryAssets/SpryMenuBarVertical.css" rel="stylesheet" type="text/css" />
    <style type="text/css">
<!--
.tudo #rodape #corpo_rodape table tr td table tr th {
	color: #FFF;
}
body,td,th {
	font-size: 12px;
	color: #000;
}
body {
	background-color: #FFF;
}
-->
    </style>
</head>

<body>
		<div class="tudo">
			<div class="corpo">
			<table width="1000" border="0" valign="top" align="center" cellpadding="0" cellspacing="0">
		<tr>
			<td height="216" colspan="6" valign="top"><table width="1000"  height="15px" border="0">
		  <tr>
			<th scope="col" height="15"><form action="" method="get"><table width="1000"  height="15"border="0">
		  <tr>
			<th width="492" scope="col">&nbsp;</th>
			<th width="250" height="15" class="texto_paginalocal" scope="col">Faça sua pesquisa pelo código ou nome do produto:</th>
			<th width="144" align="right" scope="col"><input name="" type="text" /></th>
			<th width="96" align="left" scope="col"><label>
			  <input type="submit" name="button" id="button" value="Pesquisar" />
			</label></th>
			
			</tr>
		</table>
		</form></th>
		  </tr>
		  <tr>
			<td width="1000" height="198" valign="top"><object id="FlashID" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" width="1000" height="198">
			  <param name="movie" value="swf/bANNER sITE.swf" />
			  <param name="quality" value="high" />
			  <param name="wmode" value="opaque" />
			  <param name="swfversion" value="6.0.65.0" />
			  <!-- This param tag prompts users with Flash Player 6.0 r65 and higher to download the latest version of Flash Player. Delete it if you don’t want users to see the prompt. -->
			  <param name="expressinstall" value="Scripts/expressInstall.swf" />
			  <!-- Next object tag is for non-IE browsers. So hide it from IE using IECC. -->
			  <!--[if !IE]>-->
			  <object type="application/x-shockwave-flash" data="swf/bANNER sITE.swf" width="1000" height="196">
			    <!--<![endif]-->
			    <param name="quality" value="high" />
			    <param name="wmode" value="opaque" />
			    <param name="swfversion" value="6.0.65.0" />
			    <param name="expressinstall" value="Scripts/expressInstall.swf" />
			    <!-- The browser displays the following alternative content for users with Flash Player 6.0 and older. -->
			    <div>
			      <h4>Content on this page requires a newer version of Adobe Flash Player.</h4>
			      <p><a href="http://www.adobe.com/go/getflashplayer"><img src="http://www.adobe.com/images/shared/download_buttons/get_flash_player.gif" alt="Get Adobe Flash player" width="112" height="33" /></a></p>
			      </div>
			    <!--[if !IE]>-->
			    </object>
			  <!--<![endif]-->
			  </object></td>
		  </tr>
		</table>
		</td>
			</tr>
		  <tr>
			<td colspan="6" valign="top"><span class="texto_paginalocal">Você esta navegando em</span><span class="texto_destaque"> Home</span></td>
			</tr>
		  <tr>
			<td width="164" rowspan="9" align="left" valign="top" ><ul id="MenuBar1" class="MenuBarVertical">
            	<?php include("./includes/menu_categoria.php")?>
              <!--
			  <li><a href="produtos.php">Tratores < </a>        </li>
			  <li><a href="produtos.php">Colheitadeiras / Colhedoras < </a></li>
			  <li><a href="produtos.php">Veículos < </a></li>
			  <li><a href="produtos.php">Caminhões < </a></li>
			  <li><a href="produtos.php">Ônibus < </a></li>
			  <li><a href="produtos.php">Imóveis < </a></li>
			  <li><a href="produtos.php">Animais < </a></li>
			  <li><a href="produtos.php">Máquinas Pesadas < </a></li>
			  <li><a href="produtos.php">Equipamentos Industriais < </a></li>
			  <li><a href="produtos.php">Instalações Comerciais < </a></li>
			  <li><a href="produtos.php">Instalações Rurais < </a></li>
			  <li><a href="produtos.php">Utensílios Agropecuários < </a></li>
			  <li><a href="produtos.php">Carrocerias e Furgões < </a></li>
			  <li><a href="produtos.php">Implementos Agrícolas < </a></li>
			  <li><a href="produtos.php">Serviços < </a></li>
              -->
			  </ul></td>
			<td colspan="4" align="left" valign="top"> <h2>:: Notícias</h2> 
			  <div class="div_noticias">
				<strong class="textoverde">Não caia no golpe da corretagem</strong><br />
<span class="div_noticias">Golpe da corretagem vem sendo aplicado na região oeste do Paraná Como se não bastasse a crise que vem passando o agricultor brasileiro, com os produtos agrícolas com preços que quase sempre não cobrem os custos de produção.<a href="noticias.php" class="noticia"><span class="texto_destaque">Saiba mais...</span></a>			  </div></td>
			<td width="164" rowspan="9" align="center" valign="top" bgcolor="#E8E8E8"><table width="164" border="0">
		  <tr>
			<th align="center" valign="top" scope="col"><img src="imagem/propaganda.jpg" width="164" height="152" /></th>
		  </tr>
		  <tr>
			<td align="center" valign="top"><img src="imagem/dv_prop.gif" width="164" height="14" /></td>
		  </tr>
		  <tr>
			<td align="center" valign="top"><img src="imagem/propaganda.jpg" width="164" height="152" /></td>
		  </tr>
		  <tr>
			<td align="center" valign="top"><img src="imagem/dv_prop.gif" width="164" height="14" /></td>
		  </tr>
		  <tr>
			<td align="center" valign="top"></td>
		  </tr>
		  <tr>
			<td align="center" valign="top"><img src="imagem/propaganda.jpg" width="164" height="152" /></td>
		  </tr>
		  <tr>
			<td align="center" valign="top"><img src="imagem/dv_prop.gif" width="164" height="14" /></td>
		  </tr>
		</table>
		</td>
		  </tr>
		  <tr>
			<td colspan="4"><h2>:: Negócios em Destaque</h2></td>
			</tr>
		  <tr>
			<td width="168" align="center" valign="top"><img src="imagem/produtos.jpg" width="124" height="132" /></td>
			<td width="168" align="center" valign="top"><img src="imagem/produtos.jpg" width="124" height="132" /></td>
			<td width="168" align="center" valign="top"><img src="imagem/produtos.jpg" width="124" height="132" /></td>
			<td width="168" align="center" valign="top"><img src="imagem/produtos.jpg" width="124" height="132" /></td>
			</tr>
		  <tr>
			<td height="30" align="center" valign="top"><div class="div_negocios">
				<strong class="textoverde">Trator Massey Fergusson
		  <p><a href="#"><span class="texto_destaque">Detalhes</span></a></p>
		  </div></td>
			<td height="30" align="center" valign="top"><div class="div_negocios">
				<strong class="textoverde">Trator Massey Fergusson
		  <p><a href="#"><span class="texto_destaque">Detalhes</span></a></p>
		  </div></td>
			<td height="30" align="center" valign="top"><div class="div_negocios">
				<strong class="textoverde">Trator Massey Fergusson
		  <p><a href="#"><span class="texto_destaque">Detalhes</span></a></p>
		  </div></td>
			<td align="center" valign="top"><div class="div_negocios">
				<strong class="textoverde">Trator Massey Fergusson
		  <p><a href="#"><span class="texto_destaque">Detalhes</span></a></p>
		  </div></td>
			</tr>
		  <tr>
			<td colspan="4"><h2>:: Negócios Mais Recentes</h2></td>
			</tr>
		  <tr>
			<td align="center" valign="middle"><img src="imagem/produtos.jpg" width="124" height="132" /></td>
			<td align="center" valign="middle"><p><img src="imagem/produtos.jpg" width="124" height="132" /></p></td>
			<td align="center" valign="middle"><p><img src="imagem/produtos.jpg" width="124" height="132" /></p></td>
			<td align="center" valign="middle"><p><img src="imagem/produtos.jpg" width="124" height="132" /></p></td>
			</tr>
		  <tr>
			<td><div class="div_negocios">
				<strong class="textoverde">Trator Massey Fergusson
		  <p><a href="#"><span class="texto_destaque">Detalhes</span></a></p>
		  </div></td>
			<td><div class="div_negocios">
				<strong class="textoverde">Trator Massey Fergusson
		  <p><a href="#"><span class="texto_destaque">Detalhes</span></a></p>
		  </div></td>
			<td><div class="div_negocios">
				<strong class="textoverde">Trator Massey Fergusson
		  <p><a href="#"><span class="texto_destaque">Detalhes</span></a></p>
		  </div></td>
			<td><div class="div_negocios">
				<strong class="textoverde">Trator Massey Fergusson
		  <p><a href="#"><span class="texto_destaque">Detalhes</span></a></p>
		  </div></td>
			</tr>
		  <tr>
			<td align="center" valign="top"><p><img src="imagem/produtos.jpg" width="124" height="132" /></p></td>
			<td align="center" valign="top"><p><img src="imagem/produtos.jpg" width="124" height="132" /></p></td>
			<td align="center" valign="top"><p><img src="imagem/produtos.jpg" width="124" height="132" /></p></td>
			<td align="center" valign="top"><p><img src="imagem/produtos.jpg" width="124" height="132" /></p></td>
			</tr>
		  <tr>
			<td><div class="div_negocios">
				<strong class="textoverde">Trator Massey Fergusson
		  <p><a href="#"><span class="texto_destaque">Detalhes</span></a></p>
		  </div></td>
			<td><div class="div_negocios">
				<strong class="textoverde">Trator Massey Fergusson
		  <p><a href="#"><span class="texto_destaque">Detalhes</span></a></p>
		  </div></td>
			<td><div class="div_negocios">
				<strong class="textoverde">Trator Massey Fergusson
		  <p><a href="#"><span class="texto_destaque">Detalhes</span></a></p>
		  </div></td>
			<td><div class="div_negocios">
				<strong class="textoverde">Trator Massey Fergusson
		  <p><a href="#"><span class="texto_destaque">Detalhes</span></a></p>
		  </div></td>
			</tr>
		</table>

		</div>
                   
        <div id="rodape"><div id="corpo_rodape"><table width="1000"  height="121"border="0">
		  <tr>
			<th width="627" rowspan="3" scope="col">&nbsp;</th>
			<th width="363" height="44" align="right" valign="bottom" class="texto_destaque" scope="col">Area Restita:<span class="texto_paginalocal"> <a href="login.php" class="texto_paginalocal">Entrar aqui.</a></span></th>
		  </tr>
		  <tr>
			<td width="363">
			  <table width="300" border="0" valign="top">
				<tr>
				  <th align="right" valign="top" scope="col">&nbsp;</th>
			    </tr>
			  </table>
			</td>
		  </tr>
		  <tr align="center" valign="bottom" height="41">
			<td height="12" align="right" valign="bottom"></td>
		  </tr>
		</table>
		</div></div>    
		</div>
		
	</body>
</html>
<?php	
	mysql_close($link);
?>
