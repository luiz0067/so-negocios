<script src="../SpryAssets/SpryTabbedPanels.js" type="text/javascript"></script>
<link href="../SpryAssets/SpryTabbedPanels.css" rel="stylesheet" type="text/css">
<link href="stilo_novo.css" rel="stylesheet" type="text/css">
<table width="1000" border="1">
  <tr>
    <td width="464" rowspan="4">
            <table width="500" border="1">
              <tr>
                <td width="500"><div id="TabbedPanels1" class="TabbedPanels">
                  <ul class="TabbedPanelsTabGroup">
                    <li class="TabbedPanelsTab" tabindex="0">01</li>
                    <li class="TabbedPanelsTab" tabindex="0">02</li>
                    <li class="TabbedPanelsTab" tabindex="0">03</li>
                    <li class="TabbedPanelsTab" tabindex="0">04</li>
                    <li class="TabbedPanelsTab" tabindex="0">05</li>
                    <li class="TabbedPanelsTab" tabindex="0">06</li>
                    <li class="TabbedPanelsTab" tabindex="0">07</li>
                    <li class="TabbedPanelsTab" tabindex="0">08</li>
                    <li class="TabbedPanelsTab" tabindex="0">09</li>
                    <li class="TabbedPanelsTab" tabindex="0">10</li>
                  </ul>
                  <div class="TabbedPanelsContentGroup">
                    <div class="TabbedPanelsContent"><img src="photos/image1.jpg" width="350" height="350"></div>
                    <div class="TabbedPanelsContent">Content 2</div>
                    <div class="TabbedPanelsContent">Content 3</div>
                    <div class="TabbedPanelsContent">Content 4</div>
                    <div class="TabbedPanelsContent">Content 5</div>
                    <div class="TabbedPanelsContent"><img src="photos/image1.jpg" width="350" height="350"></div>
                    <div class="TabbedPanelsContent">Content 7</div>
                    <div class="TabbedPanelsContent">Content 8</div>
                    <div class="TabbedPanelsContent">Content 9</div>
                    <div class="TabbedPanelsContent">Content 10</div>
                  </div>
                </div></td>
              </tr>
            </table></td>
    <td width="500" valign="top"><h1 class="stilo_novo">Nome:</h1></td>
  </tr>
  <tr>
    <td valign="top">Codigo:</td>
  </tr>
  <tr>
    <td valign="top"><h2 class="vermelho">Valor:</h2></td>
  </tr>
  <tr>
    <td valign="top"><p>Descricão:</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p></td>
  </tr>
  <tr>
    <td colspan="2">Obs: consulte o produto se ainda não foi vendido. antes de solicitar sua compra</td>
  </tr>
</table>

<script type="text/javascript">
<!--
var TabbedPanels1 = new Spry.Widget.TabbedPanels("TabbedPanels1");
//-->
</script>
