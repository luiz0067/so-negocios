<table width="770" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td align="center" valign="top" class="texto_centro">
	
	<a href="cadastra_user.php">Cadastrar Usu&aacute;rio</a> | 
	
	<a href="cad_adm_financeiro.php">Cadastro Adm. Financeiro </a> | 
	
	<a href="cad_cliente.php">Cadastro de Cliente </a>| 
	
	<a href="index.php">P&aacute;gina principal</a> | 
	
	<a href="destroy.php">Sair</a></td>
  </tr>
  <tr> 
    <td align="right" valign="top" class="texto_direita">
      
    </td>
  </tr>
</table>

