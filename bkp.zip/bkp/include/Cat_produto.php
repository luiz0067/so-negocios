<tr>
	<td width="168" align="center" valign="top"><img src="imagem/produtos.jpg" width="124" height="132" /></td>
</tr>
<tr>
	<td height="30" align="center" valign="top"><div class="div_negocios">
				<strong class="textoverde">Trator Massey Fergusson<p> Valor: 12,000.00
		  <p><a href="#"><span class="texto_destaque">Detalhes</span></a></p>
		  </div></td>