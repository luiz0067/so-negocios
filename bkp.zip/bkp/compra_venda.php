
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>_:: $ó Negócios ::_</title>
<link href="css/stilo.css" rel="stylesheet" type="text/css" />
<script src="SpryAssets/SpryMenuBar.js" type="text/javascript"></script>
<script src="Scripts/swfobject_modified.js" type="text/javascript"></script>
<script src="SpryAssets/SpryTabbedPanels.js" type="text/javascript"></script>
<link href="SpryAssets/SpryMenuBarVertical.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryTabbedPanels.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div class="tudo">
<div class="corpo"><table width="1000px" border="0" valign="top" align="center" cellpadding="0" cellspacing="0">
<tr>
    <td height="219" colspan="6" valign="top"><table width="1000"  height="15px" border="0">
  <tr>
    <th scope="col" height="15"><form action="" method="get"><table width="1000"  height="15"border="0">
  <tr>
    <th width="492" scope="col">&nbsp;</th>
    <th width="250" height="15" class="texto_paginalocal" scope="col">Faça sua pesquisa pelo código ou nome do produto:</th>
    <th width="144" align="right" scope="col"><input name="" type="text" /></th>
    <th width="96" align="left" scope="col"><label>
      <input type="submit" name="button" id="button" value="Pesquisar" />
    </label></th>
    
    </tr>
</table>
</form></th>
  </tr>
  <tr>
    <td width="1000" height="198" valign="top"><object id="FlashID" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" width="1000" height="198">
      <param name="movie" value="swf/bANNER sITE.swf" />
      <param name="quality" value="high" />
      <param name="wmode" value="opaque" />
      <param name="swfversion" value="6.0.65.0" />
      <!-- This param tag prompts users with Flash Player 6.0 r65 and higher to download the latest version of Flash Player. Delete it if you don’t want users to see the prompt. -->
      <param name="expressinstall" value="Scripts/expressInstall.swf" />
      <!-- Next object tag is for non-IE browsers. So hide it from IE using IECC. -->
      <!--[if !IE]>-->
      <object type="application/x-shockwave-flash" data="swf/bANNER sITE.swf" width="1000" height="196">
        <!--<![endif]-->
        <param name="quality" value="high" />
        <param name="wmode" value="opaque" />
        <param name="swfversion" value="6.0.65.0" />
        <param name="expressinstall" value="Scripts/expressInstall.swf" />
        <!-- The browser displays the following alternative content for users with Flash Player 6.0 and older. -->
        <div>
          <h4>Content on this page requires a newer version of Adobe Flash Player.</h4>
          <p><a href="http://www.adobe.com/go/getflashplayer"><img src="http://www.adobe.com/images/shared/download_buttons/get_flash_player.gif" alt="Get Adobe Flash player" width="112" height="33" /></a></p>
        </div>
        <!--[if !IE]>-->
      </object>
      <!--<![endif]-->
    </object></td>
  </tr>
</table>
</td>
    </tr>
  <tr>
    <td colspan="6" valign="top"><span class="texto_paginalocal">Você esta navegando em</span><span class="texto_destaque"> Home / Compra e Venda</span></td>
    </tr>
  <tr>
    <td width="168" rowspan="4" align="left" valign="top" ><ul id="MenuBar1" class="MenuBarVertical">
              <li><a href="produtos.php">Tratores < </a>        </li>
			  <li><a href="produtos.php">Colheitadeiras / Colhedoras < </a></li>
			  <li><a href="produtos.php">Veículos < </a></li>
			  <li><a href="produtos.php">Caminhões < </a></li>
			  <li><a href="produtos.php">Ônibus < </a></li>
			  <li><a href="produtos.php">Imóveis < </a></li>
			  <li><a href="produtos.php">Animais < </a></li>
			  <li><a href="produtos.php">Máquinas Pesadas < </a></li>
			  <li><a href="produtos.php">Equipamentos Industriais < </a></li>
			  <li><a href="produtos.php">Instalações Comerciais < </a></li>
			  <li><a href="produtos.php">Instalações Rurais < </a></li>
			  <li><a href="produtos.php">Utensílios Agropecuários < </a></li>
			  <li><a href="produtos.php">Carrocerias e Furgões < </a></li>
			  <li><a href="produtos.php">Implementos Agrícolas < </a></li>
			  <li><a href="produtos.php">Serviços < </a></li>
      </ul></td>
    <td colspan="4" align="left" width="672" valign="top"><h2>:: Cadastro de Compra e Venda</h2></td>
    <td width="210" rowspan="4" align="center" valign="top" bgcolor="#E8E8E8"><table width="164" border="0">
      <tr>
        <th align="center" valign="top" scope="col"><img src="imagem/propaganda.jpg" width="164" height="152" /></th>
        </tr>
      <tr>
        <td align="center" valign="top"><img src="imagem/dv_prop.gif" width="164" height="14" /></td>
        </tr>
      <tr>
        <td align="center" valign="top"><img src="imagem/propaganda.jpg" width="164" height="152" /></td>
        </tr>
      <tr>
        <td align="center" valign="top"><img src="imagem/dv_prop.gif" width="164" height="14" /></td>
        </tr>
      <tr>
        <td align="center" valign="top"></td>
        </tr>
      <tr>
        <td align="center" valign="top"><img src="imagem/propaganda.jpg" width="164" height="152" /></td>
        </tr>
      <tr>
        <td align="center" valign="top"><img src="imagem/dv_prop.gif" width="164" height="14" /></td>
        </tr>
  </table>
  </td>
  </tr>
  <tr>
    <td colspan="4" align="left" valign="top">
        <div id="TabbedPanels1" class="TabbedPanels">
          <ul class="TabbedPanelsTabGroup">
            <li class="TabbedPanelsTab" tabindex="0">Cadastro de Compra</li>
          <li class="TabbedPanelsTab" tabindex="0">Cadastro de Venda</li>
          </ul>
          <div class="TabbedPanelsContentGroup">
            <div class="TabbedPanelsContent"><form action="enviar_compra.php" method="post" name="form2">
          <table width="500" border="0" cellspacing="0" cellpadding="0" align="center" ><p>
            <tr>
            <td><p>Nome: </td>
            </tr>
          <tr>
            <td><input name="Nome" type="text" size="50" /></td>
          </tr>
          <tr>
            <td><p>E-mail: </td>
            </tr>
            <tr>
           <td><input type="text" name="email" size="50" /></td>
          </tr>
          <tr>
            <td><p>Fone para Contato:</td>
           </tr>
           <tr>
           <td><input type="text" name="fone" size="50" /><p class="texto_paginalocal">
             (00) 0000-0000  -  Em caso de 2 ou mais telefone separar com barra ( / )</span>
          </td>
          </tr>
           <tr>
            <td><p>Endeço: </td>
             </tr>
            <tr>
           <td><input type="text" name="end"  size="50"/><p>
             <span class="texto_paginalocal">End - Numero - Bairro</span></td>
           </tr>
            <tr>
            <td><p>Cidade: </td>
            </tr>
            <tr>
           <td><input type="text" name="cidade" /><p></td>
          </tr>
          <tr>
            <td><p>Nome do Produto: </td>
            </tr>
            <tr>
           <td><input type="text" name="produto"  size="50"/></td>
          </tr>
            <tr>
            <td><p>Código do Produto: </td>
            </tr>
          <tr>
            <td><input name="codigo" type="text" maxlength="10"/></td>
          </tr>
          <tr>
            <td><p>Deixe Aqui sua Proposta de Negócios: </td>
           </tr>
          <tr>
            <td><textarea name="mensagem" cols="40" rows="7"></textarea></td>
          </tr>
          <tr>
          <td colspan="2"><p><input type="submit" name="Submit" value="Enviar " /></td>
            </tr>
        </table></form></div>
            <div class="TabbedPanelsContent"><form action="enviar_venda.php" method="POST"  name="form3">
        <table width="500" border="0" cellspacing="0" cellpadding="0" align="center" ><p>
            <tr>
            <td><span class="texto_destaque">Aguarde a convirmação de seu cadastro, entraremos em contato. </span>              <p class="texto_destaque">Em caso de envio de fotos do produto, encaminhar ao gmail: sonegociospr@gmail.com</td>
            </tr>
            <tr>
            <td><p>Nome: </td>
            </tr>
          <tr>
            <td><input name="Nome" type="text" size="50" /></td>
          </tr>
          <tr>
            <td><p>E-mail: </td>
            </tr>
            <tr>
           <td><input type="text" name="email" size="50" /></td>
          </tr>
          <tr>
            <td><p>Fone para Contato:</td>
           </tr>
           <tr>
           <td><input type="text" name="fone" size="50" /><p class="texto_paginalocal">
             (00) 0000-0000  -  Em caso de 2 ou mais telefone separar com barra ( / )</span>
          </td>
          </tr>
           <tr>
            <td><p>Endeço: </td>
             </tr>
            <tr>
           <td><input type="text" name="end"  size="50"/><p>
             <span class="texto_paginalocal">End - Numero - Bairro</span></td>
           </tr>
            <tr>
            <td><p>Cidade: </td>
            </tr>
            <tr>
           <td><input type="text" name="cidade" /><p>           
             </td>
          </tr>
          <tr>
            <td><p>Nome do Produto: </td>
            </tr>
            <tr>
           <td><input type="text" name="nomeprod"  size="50"/></td>
          </tr>
            <tr>
            <td><p>Valor: </td>
            </tr>
          <tr>
            <td><input name="valor" type="text" maxlength="10"/></td>
          </tr>
           <tr>
            <tr>
            <td><p>Descreva as Caracteristicas do Produto: </td>
           </tr>
          <tr>
            <td><textarea name="caracproduto" cols="40" rows="7"></textarea></td>
          </tr>
          <tr>
          <td colspan="1"><p><input type="submit" name="Submit" value="Enviar " /></td>
            </tr>
            
        </table></form></div>
          </div>
        </div></td>
  </tr>
  <tr>
    <td width="672">&nbsp;</td>
     </tr>
  </table>

</div>
<div id="rodape"><div id="corpo_rodape"><table width="1000"  height="121"border="0">
  <tr>
    <th width="690" rowspan="3" scope="col">&nbsp;</th>
    <th width="300" height="44" align="right" valign="bottom" class="texto_destaque" scope="col">Esqueci minha senha!</th>
  </tr>
  <tr>
    <td width="300"><form id="form1" name="form1" method="post" action="">
      <table width="300" border="0">
        <tr>
          <th width="112" scope="col"><label>
            <input type="text" name="textfield" id="textfield"  size="10"/>
          </label></th>
          <th width="54" scope="col">Loguin</th>
          <th width="71" scope="col"><label>
            <input name="textfield2" type="text" id="textfield2" size="6" />
          </label></th>
          <th width="53" scope="col">Senha</th>
        </tr>
      </table>
    </form></td>
  </tr>
  <tr align="center" valign="bottom" height="41">
    <td height="12" align="center" valign="bottom">&nbsp;</td>
  </tr>
</table>
</div></div>

</div>
<script type="text/javascript">
<!--
var TabbedPanels1 = new Spry.Widget.TabbedPanels("TabbedPanels1");
//-->
</script>
</body>
</html>
