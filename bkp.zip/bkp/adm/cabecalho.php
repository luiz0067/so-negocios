<a href="logout.php">sair</a>
<?php	
	include('conecta.php');
	include('verifica.php');
?>