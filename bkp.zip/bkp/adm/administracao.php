<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>.::Administração::.</title>
</head>

<body><form action="upload.php" method="post" enctype="multipart/form-data" ><table width="500" border="0">
  <tr>
    <th width="68" scope="col">Arquivo:</th>
    <th width="148" align="left" scope="col"><label>
      <input type="file" name="arquivo" id="arquivo" value=""  />
    </label></th>
    <th align="left" scope="col"><label>
      <input type="submit" name="button2" id="button2" value="Enviar" />
    </label></th>
    </tr>
</table>
</form>
</body>
</html>
