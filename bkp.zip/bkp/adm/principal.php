<?php	
	include('cabecalho.php');
	include('menu.php');
	include('rodape.php');
?>