<center>
<a href="./cadastro_usuario.php">Cadastro de usuario</a><br>
<a href="./cadastro_categoria.php">Cadastro de categoria</a><br>
<a href="./cadastro_produtos.php">Cadastro de produtos</a><br>
</center>