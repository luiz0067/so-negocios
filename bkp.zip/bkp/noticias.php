<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:ice="http://ns.adobe.com/incontextediting">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>_:: Notícias ::_</title>
<link href="css/stilo.css" rel="stylesheet" type="text/css" />
<script src="SpryAssets/SpryMenuBar.js" type="text/javascript"></script>
<script src="Scripts/swfobject_modified.js" type="text/javascript"></script>
<script src="includes/ice/ice.js" type="text/javascript"></script>
<link href="SpryAssets/SpryMenuBarVertical.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div class="tudo">
<div class="corpo"><table width="1000" align="center" border="0" valign="top"cellpadding="0" cellspacing="0">
<tr>
    <td height="219" colspan="6" valign="top"><table width="1000"  height="15px" border="0">
  <tr>
    <th scope="col" height="15"><form action="" method="get"><table width="1000"  height="15"border="0">
  <tr>
    <th width="492" scope="col">&nbsp;</th>
    <th width="250" height="15" scope="col"><span class="texto_paginalocal">Faça sua pesquisa pelo código ou nome do produto:</span></th>
    <th width="144" align="right" scope="col"><input name="" type="text" /></th>
    <th width="96" align="left" scope="col"><label>
      <input type="submit" name="button" id="button" value="Pesquisar" />
    </label></th>
    
    </tr>
</table>
</form></th>
  </tr>
  <tr>
    <td width="1000" height="196" valign="top"><object id="FlashID" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" width="1000" height="196">
      <param name="movie" value="swf/bANNER sITE.swf" />
      <param name="quality" value="high" />
      <param name="wmode" value="opaque" />
      <param name="swfversion" value="6.0.65.0" />
      <!-- This param tag prompts users with Flash Player 6.0 r65 and higher to download the latest version of Flash Player. Delete it if you don’t want users to see the prompt. -->
      <param name="expressinstall" value="Scripts/expressInstall.swf" />
      <!-- Next object tag is for non-IE browsers. So hide it from IE using IECC. -->
      <!--[if !IE]>-->
      <object type="application/x-shockwave-flash" data="swf/bANNER sITE.swf" width="1000" height="196">
        <!--<![endif]-->
        <param name="quality" value="high" />
        <param name="wmode" value="opaque" />
        <param name="swfversion" value="6.0.65.0" />
        <param name="expressinstall" value="Scripts/expressInstall.swf" />
        <!-- The browser displays the following alternative content for users with Flash Player 6.0 and older. -->
        <div>
          <h4>Content on this page requires a newer version of Adobe Flash Player.</h4>
          <p><a href="http://www.adobe.com/go/getflashplayer"><img src="http://www.adobe.com/images/shared/download_buttons/get_flash_player.gif" alt="Get Adobe Flash player" width="112" height="33" /></a></p>
        </div>
        <!--[if !IE]>-->
      </object>
      <!--<![endif]-->
    </object></td>
  </tr>
</table>
</td>
    </tr>
  <tr>
    <td colspan="6" valign="top"><span class="texto_paginalocal">Você esta navegando em</span><span class="texto_destaque"> Notícias</span></td>
    </tr>
  <tr>
    <td width="164" rowspan="4" align="left" valign="top" ><ul id="MenuBar1" class="MenuBarVertical">
     <li><a href="tratores.html">Tratores < </a>        </li>
      <li><a href="colheitadeiras.html">Colheitadeiras / Colhedoras < </a></li>
      <li><a href="veiculos.html">Veículos < </a></li>
      <li><a href="caminhoes.html">Caminhões < </a></li>
      <li><a href="onibus.html">Ônibus < </a></li>
      <li><a href="imoveis.html">Imóveis < </a></li>
      <li><a href="animais.html">Animais < </a></li>
      <li><a href="maquinas_pesadas.html">Máquinas Pesadas < </a></li>
      <li><a href="equipamentos_industriais.html">Equipamentos Industriais < </a></li>
      <li><a href="instalacoes_comerciais.html">Instalações Comerciais < </a></li>
      <li><a href="instalacoes_rurais.html">Instalações Rurais < </a></li>
      <li><a href="utensilios_agropecuarios.html">Utensílios Agropecuários < </a></li>
      <li><a href="carrocerias_furgoes.html">Carrocerias e Furgões < </a></li>
      <li><a href="implementos_agricolas.html">Implementos Agrícolas < </a></li>
      <li><a href="servicos.html">Serviços < </a></li>
      </ul></td>
    <td colspan="4" align="left"  width="672"valign="top"> <h2>:: Notícias</h2> 
      <div class="div_noticias" ice:editable="*">
        <strong class="textoverde">Não caia no golpe da corretagem</strong><br />
        <p>Golpe da corretagem vem sendo aplicado na região oeste do Paraná
          Como se não bastasse a crise que vem passando o agricultor brasileiro,
          com os produtos agrícolas com preços que quase sempre não cobrem os
          custos de produção.</p>
        <p> Produtores paranaenses quando querem vender suas 
          propriedades rurais, vem sofrendo com diferentes golpes aplicados por estelionatários. Os mesmos se apresentam como corretores e trazem supostos compradores para a propriedade, muitas vezes prometendo pagar um valor acima do que vale, o que deixa o produtor entusiasmado. Após o negócio aparentemente ser fechado, com o pagamento da entrada em cheque roubado e promessa de pagamento futuro do restante, o falso corretor exige o pagamento da corretagem por parte do produtor, que quase sempre representa 5% do valor da propriedade.</p>
        <p>
          Após o pagamento ser efetuado, desaparecem corretor e comprador, deixando mais uma vez o produtor rural no prejuízo. O produtor envergonhado por ter caído em um golpe, geralmente não comunica a polícia, nem os vizinhos, o que acaba auxiliando os golpistas a fazerem mais vítimas nas proximidades.</p>
        <p> O grupo SÓ NEGÓCIOS condena esta, e todas as práticas idôneas onde alguém seja lesado. <br />
          Nossos clientes são cadastrados, para garantir maior segurança para o produtor rural, e, nossos corretores não recebem comissão antecipada a compensação dos cheques quando estes são dados como entrada!</p>
        <p>Desconfie de compradores que oferecem um valor acima do que vale na região, e, não pague a corretagem antes de estar com o dinheiro compensado em sua conta bancária.</p>
        <p>Prestamos assistência jurídica!<br />
          Consulte nossos advogados na hora de vender sua propriedade!<br />
          .<br />
        </p>
      </div></td>
    <td width="164" rowspan="4" align="center" valign="top" bgcolor="#E8E8E8"><table width="164" border="0">
  <tr>
    <th align="center" valign="top" scope="col"><img src="imagem/propaganda.jpg" width="164" height="152" /></th>
  </tr>
  <tr>
    <td align="center" valign="top"><img src="imagem/dv_prop.gif" width="164" height="14" /></td>
  </tr>
  <tr>
    <td align="center" valign="top"><img src="imagem/propaganda.jpg" width="164" height="152" /></td>
  </tr>
  <tr>
    <td align="center" valign="top"><img src="imagem/dv_prop.gif" width="164" height="14" /></td>
  </tr>
  <tr>
    <td align="center" valign="top"></td>
  </tr>
  <tr>
    <td align="center" valign="top"><img src="imagem/propaganda.jpg" width="164" height="152" /></td>
  </tr>
  <tr>
    <td align="center" valign="top"><img src="imagem/dv_prop.gif" width="164" height="14" /></td>
  </tr>
</table>
</td>
  </tr>
  <tr>
    <td colspan="4" width="672"></td>
  </tr>
  <tr>
    <td width="672">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="4" align="center" valign="top" width="672"></td>
  </tr>
  </table>

</div>
<div id="rodape"><div id="corpo_rodape"><table width="1000"  height="121"border="0">
  <tr>
    <th width="690" rowspan="3" scope="col">&nbsp;</th>
    <th width="300" height="44" align="right" valign="bottom" class="texto_destaque" scope="col">Esqueci minha senha!</th>
  </tr>
  <tr>
    <td width="300"><form id="form1" name="form1" method="post" action="">
      <table width="300" border="0">
        <tr>
          <th width="112" scope="col"><label>
            <input type="text" name="textfield" id="textfield"  size="10"/>
          </label></th>
          <th width="54" scope="col">Loguin</th>
          <th width="71" scope="col"><label>
            <input name="textfield2" type="text" id="textfield2" size="6" />
          </label></th>
          <th width="53" scope="col">Senha</th>
        </tr>
      </table>
    </form></td>
  </tr>
  <tr align="center" valign="bottom" height="41">
    <td height="12" align="center" valign="bottom">&nbsp;</td>
  </tr>
</table>
</div></div>

</div>
<script type="text/javascript">
<!--
var MenuBar1 = new Spry.Widget.MenuBar("MenuBar1", {imgRight:"SpryAssets/SpryMenuBarRightHover.gif"});
//-->
</script>
</body>
</html>
